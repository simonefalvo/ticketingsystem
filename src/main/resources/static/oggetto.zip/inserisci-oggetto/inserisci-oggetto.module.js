'use strict';

angular.module('inserisciOggetto', []);