'use strict';

angular.
module('login').
config(['$locationProvider' ,'$routeProvider',
    function config($locationProvider, $routeProvider) {
        $locationProvider.hashPrefix('!');

        $routeProvider.
        when('/log-in', {
            template: '<dash></dash>'
        }).
        when('/register', {
            template: '<registra-utente></registra-utente>'
        }).
        /*
        when('/grafico', {
            templateUrl: "../visualizza-grafico/visualizza-grafico.html"
            ,
            controller: "GraphController"

        }).
        */
        otherwise('/');
    }
]);