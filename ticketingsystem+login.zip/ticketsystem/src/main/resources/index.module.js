'use strict';

// Define the `ticketingSystemApp` module
angular.module('login', [
    'ticketingSystemApp',
    'register',
    'ngRoute'
]);