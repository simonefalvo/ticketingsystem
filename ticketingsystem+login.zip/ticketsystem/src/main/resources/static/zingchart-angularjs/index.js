require('./src/zingchart-angularjs');
module.exports = 'zingchart-angularjs';
