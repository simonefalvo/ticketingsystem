'use strict';

angular.module('inserisciTicket', []);