'use strict';

angular.module('registraUtente', []);