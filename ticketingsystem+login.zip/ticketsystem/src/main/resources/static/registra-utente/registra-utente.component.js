'use strict';

// Register `inserisciUtente` component, along with its associated controller and template
angular.
module('registraUtente').
component('registraUtente', {
    templateUrl: 'registra-utente/registra-utente.template.html',
    controller: ['$http', '$location', function registraUtenteController($http, $location) {

        var self = this;

        self.inserisci = function () {
            //console.log(self.utente);
            $http.post('utente/', self.utente)
                .then(function (response) {
                    $location.path('/utente');
                    alert("utente inserito con successo!");
                }, function (reason) {
                    alert('Error: ' + JSON.stringify(reason));
                });
        };

        self.annulla = function () {
            $location.path('/utente');
        };
    }]
});