'use strict';

angular.module('inserisciUtente', []);
