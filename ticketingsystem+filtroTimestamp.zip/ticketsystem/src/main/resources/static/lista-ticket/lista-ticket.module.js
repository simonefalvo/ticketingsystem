'use strict'

angular.module('listaTicket', []);