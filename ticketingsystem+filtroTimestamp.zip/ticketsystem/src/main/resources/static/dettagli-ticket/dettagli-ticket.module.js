'use strict';

// Define the `dettagliTicket` module
angular.module('dettagliTicket', [
    'ngRoute'
]);