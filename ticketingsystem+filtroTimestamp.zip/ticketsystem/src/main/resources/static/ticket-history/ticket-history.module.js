'use strict';

// Define the `ticketHistory` module
angular.module('ticketHistory', [
    'ngRoute'
    //'operationFilter'
]);