'use strict';

// Define the `listaOggetto` module
angular.module('listaOggetto', []);