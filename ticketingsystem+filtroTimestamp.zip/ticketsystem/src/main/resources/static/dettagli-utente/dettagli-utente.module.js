'use strict';

// Define the `dettagliUtente` module
angular.module('dettagliUtente', [
    'ngRoute'
]);