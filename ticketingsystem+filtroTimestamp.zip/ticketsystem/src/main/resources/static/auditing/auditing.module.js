'use strict';

// Define the `auditing` module
angular.module('auditing', [
    'zingchart-angularjs'
]);