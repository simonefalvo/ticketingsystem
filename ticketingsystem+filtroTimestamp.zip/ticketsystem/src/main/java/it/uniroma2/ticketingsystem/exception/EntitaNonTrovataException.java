package it.uniroma2.ticketingsystem.exception;

public class EntitaNonTrovataException extends Exception {
}

