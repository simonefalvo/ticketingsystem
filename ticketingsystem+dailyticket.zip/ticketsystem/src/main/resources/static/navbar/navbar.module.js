'use strict';

// Define the `navbar` module
angular.module('navbar', []);