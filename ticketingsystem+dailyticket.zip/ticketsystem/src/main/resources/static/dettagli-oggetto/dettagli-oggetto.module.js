'use strict';

// Define the `dettagliOggetto` module
angular.module('dettagliOggetto', [
    'ngRoute'
]);