'use strict';

// Define the `listaUtente` module
angular.module('listaUtente', []);