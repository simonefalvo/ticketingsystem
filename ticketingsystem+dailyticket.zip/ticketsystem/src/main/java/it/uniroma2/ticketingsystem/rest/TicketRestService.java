package it.uniroma2.ticketingsystem.rest;

import it.uniroma2.ticketingsystem.controller.TicketController;
import it.uniroma2.ticketingsystem.entity.Ticket;
import it.uniroma2.ticketingsystem.exception.EntitaNonTrovataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "ticket")
public class TicketRestService {


    @Autowired
    private TicketController ticketController;

    @RequestMapping(path = "", method = RequestMethod.POST)
    public ResponseEntity<Ticket> creaTicket(@RequestBody Ticket ticket) {
        Ticket ticketCreato = ticketController.creaTicket(ticket);
        return new ResponseEntity<>(ticketCreato, HttpStatus.CREATED);
    }

    @RequestMapping(path = "{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Boolean> eliminaTicket(@PathVariable Integer id) {
        boolean ticketEliminato = ticketController.eliminaTicket(id);
        return new ResponseEntity<>(ticketEliminato, ticketEliminato ? HttpStatus.OK : HttpStatus.NOT_FOUND);
    }

    @RequestMapping(path = "{id}", method = RequestMethod.GET)
    public ResponseEntity<Ticket> cercaTicket(@PathVariable Integer id) {
        Ticket ticketTrovato = ticketController.cercaTicketById(id);
        return new ResponseEntity<>(ticketTrovato, ticketTrovato == null ? HttpStatus.NOT_FOUND : HttpStatus.CREATED);
    }

    @RequestMapping(path = "", method = RequestMethod.GET)
    public ResponseEntity<List<Ticket>> prelevaTickets() {
        List<Ticket> ticket = ticketController.prelevaTickets();
        return new ResponseEntity<>(ticket, HttpStatus.OK);
    }

    @RequestMapping(path = "{id}", method = RequestMethod.PUT)
    public ResponseEntity<Ticket> aggiornaTicket(@PathVariable Integer id, @RequestBody Ticket ticket) {
        Ticket ticketAggiornato;
        try {
            ticketAggiornato = ticketController.aggiornaTicket(id, ticket);
        } catch (EntitaNonTrovataException e) {
            return new ResponseEntity<>(ticket, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(ticketAggiornato, HttpStatus.OK);
    }
}
