package it.uniroma2.ticketingsystem.logger.exception;

public class AttrNotFoundException extends Exception {

    public AttrNotFoundException(String message) {
        super(message);
    }
}

