package it.uniroma2.ticketingsystem.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;

@Document
@NoArgsConstructor
@Getter
@Setter
public class Cane {

    private @Id String id;
    private String nome;

    public Cane(@NotNull String nome) {
        this.nome = nome;
    }

    public void aggiorna(@NotNull Cane datiAggiornati) {
        this.nome = datiAggiornati.nome;
    }
}
