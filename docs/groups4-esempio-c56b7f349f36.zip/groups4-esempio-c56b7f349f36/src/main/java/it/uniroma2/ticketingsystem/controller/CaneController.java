package it.uniroma2.ticketingsystem.controller;

import it.uniroma2.ticketingsystem.dao.CaneDao;
import it.uniroma2.ticketingsystem.entity.Cane;
import it.uniroma2.ticketingsystem.exception.EntitaNonTrovataException;
import it.uniroma2.ticketingsystem.logger.aspect.LogOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

// @Service identifica uno Spring Bean che nell'architettura MVC è un Controller
@Service
public class CaneController {

    @Autowired
    private CaneDao caneDao;

    @LogOperation(returnObject = true)
    public @NotNull Cane creaCane(@NotNull Cane cane) {
        Cane caneSalvata = caneDao.save(cane);
        return caneSalvata;
    }

    public @NotNull Cane aggiornaCane(@NotNull String id, @NotNull Cane datiAggiornati) throws EntitaNonTrovataException {
        Optional<Cane> caneDaAggiornare = caneDao.findById(id);
        if (caneDaAggiornare.isPresent())
            throw new EntitaNonTrovataException();

        caneDaAggiornare.get().aggiorna(datiAggiornati);

        Cane caneAggiornata = caneDao.save(caneDaAggiornare.get());
        return caneAggiornata;
    }

    public Cane cercaCanePerId(@NotNull String id) {
        Optional<Cane> caneTrovata = caneDao.findById(id);
        if (caneTrovata.isPresent())
            return caneTrovata.get();
        else
            return null;
    }

    public boolean eliminaCane(@NotNull String id) {
        if (!caneDao.existsById(id)) {
            return false;
        }

        caneDao.deleteById(id);
        return true;
    }

    public List<Cane> prelevaCani() {
        return caneDao.findAll();
    }
}
