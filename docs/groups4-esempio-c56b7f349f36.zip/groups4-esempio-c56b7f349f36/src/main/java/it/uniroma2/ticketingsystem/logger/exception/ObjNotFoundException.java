package it.uniroma2.ticketingsystem.logger.exception;

public class ObjNotFoundException extends Exception {

    public ObjNotFoundException(String message) {
        super(message);
    }
}

