package it.uniroma2.ticketingsystem.logger.exception;

public class KeyNotFoundException extends Exception {

    public KeyNotFoundException(String message) {
        super(message);
    }
}

