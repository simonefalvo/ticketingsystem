package it.uniroma2.ticketingsystem.dao;

import it.uniroma2.ticketingsystem.entity.Cane;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CaneDao extends MongoRepository<Cane, String> {
}
