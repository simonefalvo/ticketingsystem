package it.uniroma2.ticketingsystem;

import it.uniroma2.ticketingsystem.dao.CaneDao;
import it.uniroma2.ticketingsystem.dao.PersonaDao;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

//@EnableJpaRepositories(basePackageClasses = PersonaDao.class)
//@EnableMongoRepositories(basePackageClasses = CaneDao.class)
@SpringBootApplication
public class TicketingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketingSystemApplication.class, args);
	}
}
